require(['delta'], function () {

});
